<?php
    const HOSTNAME = 'localhost';
    const USERNAME = 'root';
    const PASSWORD = '';
    const DATABASE = 'BearBurger_PHP';