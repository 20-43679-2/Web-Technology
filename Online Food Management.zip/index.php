<?php
    header("Location: application/views/Welcome.php");
    die();
