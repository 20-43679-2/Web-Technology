</body>

<footer class="footer">
    <p>Thank you for visiting our website. Please try our restaurant spots.</p>
</footer>

</html>